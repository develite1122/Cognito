// import styled from "styled-components";
// const AppHeader = styled.header`
//   height: 5rem;
//   display: flex;
//   padding: 1rem;
//   font-size: 2rem;
//   justify-content: space-between;
//   align-items: center;
//   width: 100%;
//   margin: 20px;
// `;
import { Link } from "react-router-dom";
import ShoppingCartIcon from "./cart.icon";
import logo from "../../../public/images/bluelogo.png";
import React from "react";

const AppHeader = () => {
  return (
    <div className="top_header">
      <img src={logo} alt="Logo" className="logoImage" />
      <Link to="https://cognitoedu.org/aboutus" className="nav_products_link">
        About
      </Link>
      <Link to="/" className="nav_products_link">
        Products
      </Link>

      <ShoppingCartIcon />
    </div>
  );
};

export default AppHeader;
