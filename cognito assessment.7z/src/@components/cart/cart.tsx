import React, { useContext } from "react";
import ProductContext from "../../@contexts/product.context";
import ProductRow from "../products/product.row";
import ShoppingCartTotal from "./cart.total";

export interface IShoppingCartPageProps {}

export default function ShoppingCartPage(props: IShoppingCartPageProps) {
  const { cart } = useContext(ProductContext);
  return (
    <div>
      {cart?.length > 0 ? (
        <table className="m_table" data-testid="product-table">
          <thead className="m_thead-dark">
            <tr>
              <th>Num</th>
              <th>Name</th>
              <th>Price</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody data-testid="product-table-body">
            {cart.map((p, i) => (
              <ProductRow product={p} key={p.id} />
            ))}
          </tbody>
        </table>
      ) : (
        <span className="basket_empty">Basket is empty</span>
      )}
      <ShoppingCartTotal />
    </div>
  );
}
