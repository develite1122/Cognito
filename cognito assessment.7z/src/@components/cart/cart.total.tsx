import React, { useContext } from "react";
import ProductContext from "../../@contexts/product.context";

export interface IShoppingCartTotalProps {}

export default function ShoppingCartTotal(props: IShoppingCartTotalProps) {
  const { cart } = useContext(ProductContext);
  const total = cart.reduce<number>((total, p) => total + p.price, 0);
  return (
    <>
      {total !== 0 && (
        <div className="total_price">
          <div>Total Price: ${total}</div>
        </div>
      )}
    </>
  );
}
