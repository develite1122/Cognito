import * as React from "react";
import { Link } from "react-router-dom";
import ProductContext from "../../@contexts/product.context";
import { IProduct } from "../../@types/product";

export interface IProductRowProps {
  product: IProduct;
}

export default function ProductRow(props: IProductRowProps) {
  const { product } = props;
  const { name, price, id, description } = product;
  const { addToCart } = React.useContext(ProductContext);

  return (
    <tr className="align-middle">
      <td>{id}</td>
      <td data-testid="name">{name}</td>
      <td>${price}</td>
      <td>
        <Link
          to={`/${id}`}
          className="btn btn-outline-info  m-2"
          data-testid="edit-button"
        >
          Show Detail
        </Link>
        <button
          className="btn btn-outline-success  m-2"
          onClick={() => {
            addToCart(product);
          }}
          data-testid="add-to-cart"
        >
          Add to cart
        </button>
      </td>
    </tr>
  );
}
