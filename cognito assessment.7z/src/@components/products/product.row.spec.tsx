import { fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import { BrowserRouter } from "react-router-dom";
import ProductContext, {
  IProductContextProps,
} from "../../@contexts/product.context";
import { IProduct } from "../../@types/product";
import { demoProducts } from "../../data.sample";
import ProductRow from "./product.row";
import ProductTable from "./product.table";
import { testProductContextValue } from "../../@contexts/mocks/product.context.mock";

const testContextValue: IProductContextProps = testProductContextValue;

const ProductRowTestComponent = (props: {
  contextValue: IProductContextProps;
  product: IProduct;
}) => {
  const { contextValue, product } = props;
  return (
    <ProductContext.Provider value={contextValue}>
      <BrowserRouter>
        <ProductRow product={product} />
      </BrowserRouter>
    </ProductContext.Provider>
  );
};

describe("Testing on Product Detail Button", () => {
  it("should go to detail page when detail button clicked", async () => {
    const product: IProduct = {
      name: "Gala Apples (5 lbs)",
      price: 3.49,
      description: "Crisp and delicious apples for a healthy snack.",
    };
    const { getByTestId } = render(
      <ProductRowTestComponent
        contextValue={testContextValue}
        product={product}
      />
    );

    const detailBtn = getByTestId("edit-button");
    fireEvent.click(detailBtn);
    expect(location.pathname).toBe(`/${product.id}`);
  });
});
