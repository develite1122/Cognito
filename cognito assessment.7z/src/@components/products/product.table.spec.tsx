import React from "react";
import ProductContext, {
  IProductContextProps,
  ProductContextProvider,
} from "../../@contexts/product.context";
import ProductTable from "./product.table";
import { render, screen, renderHook, fireEvent } from "@testing-library/react";
import { IProduct } from "../../@types/product";
import { demoProducts } from "../../data.sample";
import { Router } from "react-router";
import { BrowserRouter } from "react-router-dom";
import { testProductContextValue } from "../../@contexts/mocks/product.context.mock";

const testContextValue: IProductContextProps = testProductContextValue;

const ProductTableTestComponent = (contextValue: IProductContextProps) => {
  return (
    <ProductContext.Provider value={contextValue}>
      <BrowserRouter>
        <ProductTable />
      </BrowserRouter>
    </ProductContext.Provider>
  );
};
describe("Testing on Products", () => {
  it("should display products", async () => {
    const contextValue: IProductContextProps = {
      ...testContextValue,
      products: demoProducts,
    };
    const { container } = render(
      <ProductTableTestComponent {...contextValue} />
    );
    const tBody = await screen.findByTestId("product-table-body");
    expect(tBody.getElementsByTagName("tr").length).toBe(demoProducts.length);
  });
});
