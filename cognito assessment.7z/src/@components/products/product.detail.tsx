import * as React from "react";
import { useNavigate, useParams } from "react-router-dom";
import { IProduct, ProductType } from "../../@types/product";
import { useForm } from "react-hook-form";
import ProductContext from "../../@contexts/product.context";

export default function ProductDetail() {
  const params = useParams();
  const { id } = params;
  console.log(id);
  const navigate = useNavigate();

  const { getValues, register, setValue } = useForm<IProduct>({});

  const { getProduct } = React.useContext(ProductContext);

  const onSubmit = () => {
    navigate("/");
  };

  React.useEffect(() => {
    const p = getProduct(Number(id));
    console.log(p);
    if (!p) {
      navigate("/");
      return;
    }
    for (let key of Object.keys(p) as (keyof IProduct)[]) {
      setValue(key, p[key]);
    }
  }, [id]);

  return (
    <div className="">
      <form className="m-auto d-flex flex-column gap-4" style={{ width: 400 }}>
        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            {...register("name")}
            className="form-control"
            data-testid="name"
            disabled
          />
        </div>
        <div className="form-group">
          <label>Price</label>
          <input
            type="number"
            {...register("price")}
            className="form-control"
            disabled
          />
        </div>
        <div className="form-group">
          <label>description</label>
          <input
            type="textarea"
            {...register("description")}
            className="form-control"
            disabled
          />
        </div>
        <div className="form-group">
          <input
            type="button"
            data-testid="submit"
            value="Back"
            className="btn btn-primary"
            onClick={onSubmit}
          />
        </div>
      </form>
    </div>
  );
}
