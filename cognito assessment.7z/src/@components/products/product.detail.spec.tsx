import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import { BrowserRouter, MemoryRouter } from "react-router-dom";

import ProductContext, {
  IProductContextProps,
} from "../../@contexts/product.context";
import { IProduct } from "../../@types/product";
import { demoProducts } from "../../data.sample";
import ProductDetail from "./product.detail";
import ProductRow from "./product.row";
import ProductTable from "./product.table";
import { testProductContextValue } from "../../@contexts/mocks/product.context.mock";
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"), // use actual for all non-hook parts
  useParams: jest.fn(() => ({
    id: "1",
  })),
}));

const testContextValue: IProductContextProps = testProductContextValue;
const ProductDetailTestComponent = (props: {
  contextValue: IProductContextProps;
}) => {
  const { contextValue } = props;
  return (
    <ProductContext.Provider value={contextValue}>
      <BrowserRouter>
        <ProductDetail />
      </BrowserRouter>
    </ProductContext.Provider>
  );
};

describe("Testing on Product Detail & Edit & Add", () => {
  beforeEach(() => {});
  afterEach(() => {
    cleanup();
  });

  it("should display product from product id", async () => {
    const product: IProduct = {
      id: 2,
      name: "Gala Apples (5 lbs)",
      price: 3.49,
      description: "Crisp and delicious apples for a healthy snack.",
    };
    const getProduct = jest.fn((id: number) => product);
    //jest.spyOn(ReactRouter, "useParams").mockReturnValue({ id: "1" });

    const {
      container,
      getByTestId,
      getByText,
      getByDisplayValue,
      getByPlaceholderText,
    } = render(
      <ProductDetailTestComponent
        contextValue={{ ...testContextValue, getProduct }}
      />
    );
    expect(getProduct).toHaveBeenCalled();
    expect(getByDisplayValue(/Crisp/)).toBeInTheDocument();
    expect(getByDisplayValue("Gala Apples (5 lbs)")).toBeInTheDocument();
    expect(getByDisplayValue("3.49")).toBeInTheDocument();
  });
});
