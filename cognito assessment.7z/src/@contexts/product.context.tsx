import React, {
  createContext,
  PropsWithChildren,
  useContext,
  useEffect,
  useState,
} from "react";
import { reduce } from "underscore";
import { IProduct } from "../@types/product";

export interface IProductContextProps {
  products: IProduct[];
  getProduct: (productid: number) => IProduct | null;

  cart: IProduct[];
  addToCart: (product: IProduct) => void;
  removeFromCart: (productId: number) => void;
}
const ProductContext = createContext<IProductContextProps>(
  {} as IProductContextProps
);

export const ProductContextProvider: React.FC<PropsWithChildren> = ({
  children,
}) => {
  const [products, setProducts] = useState<IProduct[]>([]);
  const [cart, setCart] = useState<IProduct[]>([]);

  async function fetchData() {
    try {
      const response = await fetch(
        "https://s3.eu-west-2.amazonaws.com/techassessment.cognitoedu.org/products.json"
      );
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      const data = await response.json();
      return data;
    } catch (error) {
      throw error;
    }
  }

  useEffect(() => {
    fetchData()
      .then((data) => {
        setProducts(data);
      })
      .catch((err) => {
        console.error("Fetch error:", err);
      });
  }, []);

  const getProduct = (productid: number) => {
    return products.find((p) => p.id === productid) ?? null;
  };
  const addToCart = (product: IProduct) => {
    setCart((cart) => [...cart, product]);
  };
  const removeFromCart = (productId: number) => {
    setCart((cart) => cart.filter((p) => p.id !== productId));
  };
  return (
    <ProductContext.Provider
      value={{
        getProduct,
        products,
        cart,
        addToCart,
        removeFromCart,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};

export default ProductContext;
