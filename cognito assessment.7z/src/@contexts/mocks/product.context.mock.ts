import { demoProducts } from "../../data.sample";
import { IProductContextProps } from "../product.context";

export const testProductContextValue: IProductContextProps = {
  getProduct: jest.fn(),
  products: demoProducts,

  addToCart: jest.fn(),
  removeFromCart: jest.fn(),
  cart: [],
};
