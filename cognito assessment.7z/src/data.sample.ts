export const demoProducts = [
  {
    "id": 1,
    "name": "Gala Apples (5 lbs)",
    "description": "Crisp and delicious apples for a healthy snack.",
    "price": 3.49
  },
  {
    "id": 2,
    "name": "UK-Grade Ground Beef (1 lb)",
    "description": "High-quality ground beef for your favorite recipes.",
    "price": 5.99
  },
  {
    "id": 3,
    "name": "Organic Milk (1 gallon)",
    "description": "Nutrient-rich organic milk for the family.",
    "price": 1.99
  },
  {
    "id": 4,
    "name": "Fresh Broccoli (per bunch)",
    "description": "Tender broccoli for steaming or roasting.",
    "price": 1.49
  }
];